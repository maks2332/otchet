package com.example.myapplication

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Patterns
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.gotrue.providers.builtin.Email
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlinx.serialization.Serializer

class registrClass : AppCompatActivity() {
    companion object {
        private val ConnectBDClass = Connact_bd()
    }
    var selectedRole: String? = null
    val supabase = ConnectBDClass.supabase
    var mail: String? = null
    var pass: String? = null
    var username: String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.registr_activity)
        val editEmail: EditText = findViewById(R.id.email_edit)
        val editUser: EditText = findViewById(R.id.username_edit)
        val editPass = findViewById(R.id.password_edit) as EditText
        val btnLog: Button = findViewById(R.id.btn_log_1)
        val btnReg = findViewById(R.id.btn_reg_1) as Button
        val radioGroup = findViewById<RadioGroup>(R.id.radioGroup)
        btnLog.isEnabled=false

        editEmail.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
                btnLog.isEnabled=false
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0.isValidEmail()){
                    editEmail.error = null
                    btnLog.isEnabled=true
                }else{
                    editEmail.error = "Введите E-mail."
                    btnLog.isEnabled=false
                }
            }
            override fun afterTextChanged(p0: Editable?) {
                mail = editEmail.text.toString()
            }
        })

        editPass.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
                btnLog.isEnabled=false
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0 != null) {
                    if (p0.trim().length>6){
                        editPass.error = null
                        btnLog.isEnabled=true
                    }else{
                        editPass.error = "Нужно ввести пароль."
                    }
                }
            }
            override fun afterTextChanged(p0: Editable?) {
                pass = editPass.text.toString()
            }

        })
        editUser.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
                btnLog.isEnabled=false
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0 != null) {
                    if (p0.trim().length>6){
                        editUser.error = null
                        btnLog.isEnabled=true
                    }else{
                        editUser.error = "Нужно ввести пароль."
                    }
                }
            }
            override fun afterTextChanged(p0: Editable?) {
                username = editUser.text.toString()
            }

        })
        radioGroup.setOnCheckedChangeListener{ group, checkedId ->
            selectedRole = when(checkedId){
                R.id.radio_patient -> "Patient"
                R.id.radio_dok -> "Dok"
                else -> null
            }

        }
        btnLog.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View?) {


            }
        })
        btnReg.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View?) {
                lifecycleScope.launch {
                    val user = supabase.auth.signUpWith(Email) {
                        email = mail.toString()
                        password = pass.toString()
                    }
                if (selectedRole == "Dok"){
                    lifecycleScope.launch {
                        val user = supabase.auth.retrieveUserForCurrentSession(updateSession = true)
                        val toUpsert = User(id = user.id.toString(), role = selectedRole.toString(), name = username.toString())
                        supabase.from("userRole").upsert(toUpsert)
                    }

                } else if(selectedRole == "Patient") {
                    lifecycleScope.launch {
                        val user = supabase.auth.retrieveUserForCurrentSession(updateSession = true)
                        val toUpsert = User(id = user.id.toString(), role = selectedRole.toString(), name = username.toString())
                        supabase.from("userRole").upsert(toUpsert)
                    }
                }
                }
            }
        })

    }
}


fun CharSequence?.isValidEmail():Boolean{
    return !isNullOrEmpty() && Patterns
        .EMAIL_ADDRESS.matcher(this).matches()
}
@Serializable
data class User(var role: String,var id: String, var name:String)