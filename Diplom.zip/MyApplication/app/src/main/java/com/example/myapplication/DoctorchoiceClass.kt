package com.example.myapplication

class DoctorchoiceClass {
}