package com.example.myapplication

import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.gotrue.Auth
import io.github.jan.supabase.postgrest.Postgrest

class Connact_bd {

    val supabase = createSupabaseClient(
        supabaseUrl = "https://xrytgyltntjzwtaelbeg.supabase.co",
        supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhyeXRneWx0bnRqend0YWVsYmVnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTIzOTY1NDIsImV4cCI6MjAyNzk3MjU0Mn0.HyHL5cF8r6H6YAfF2nLZ2G4xX0ucu1bIvTuLah5Uzao"
    ) {
        install(Auth)
        install(Postgrest)
    }
}