package com.example.myapplication

class AddendumClass {
}